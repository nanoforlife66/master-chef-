# Ingredients for Lava Cake
1. 135 135 Gram Dark chocolate
2. 95 gram Butter
3. 100 gram Icing sugar
4. 2 each Egg yolks + whole eggs
5. 35 gram Flour

###  Key Ingredients 
Dark chocolate, Butter, Icing sugar, Egg yolks + whole eggs, Flour